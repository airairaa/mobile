import 'package:flutter/material.dart';

class HariPage extends StatefulWidget {
  @override
  _HariPageState createState() => _HariPageState();
}

class _HariPageState extends State<HariPage> {
  final _hariController = TextEditingController();
  String _namaHari = '';

  void _hitung() {
    int hari = int.tryParse(_hariController.text) ?? 0;
    setState(() {
      switch (hari) {
        case 1:
          _namaHari = 'Senin';
          break;
        case 2:
          _namaHari = 'Selasa';
          break;
        case 3:
          _namaHari = 'Rabu';
          break;
        case 4:
          _namaHari = 'Kamis';
          break;
        case 5:
          _namaHari = 'Jumat';
          break;
        case 6:
          _namaHari = 'Sabtu';
          break;
        case 7:
          _namaHari = 'Minggu';
          break;
        default:
          _namaHari = 'Masukkan angka 1-7';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Penghitung Hari')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _hariController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Masukkan Angka (1-7)'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _hitung, child: Text('Cari Hari')),
            const SizedBox(height: 20),
            Text('Hari  : $_namaHari'),
          ],
        ),
      ),
    );
  }
}
