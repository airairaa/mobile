import 'package:flutter/material.dart';
import 'layanglayang.dart';
import 'tabung.dart';
import 'hari.dart';
import 'data_diri.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kuis TPM 201',
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu Aplikasi Geometri'),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: [
            Card(
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Layanglayang()),
                  );
                },
                child: Center(
                  child: Text('Layang - layang'),
                ),
              ),
            ),
            Card(
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Tabung()),
                  );
                },
                child: Center(child: Text('Tabung')),
              ),
            ),
            Card(
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HariPage()),
                  );
                },
                child: Center(child: Text('Penghitung Hari')),
              ),
            ),
            Card(
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => DataDiriPage()),
                  );
                },
                child: Center(child: Text('Data Diri')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
