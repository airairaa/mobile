import 'package:flutter/material.dart';

class DataDiriPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Data Diri'),
        backgroundColor: Colors.pinkAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 80,
              backgroundImage: AssetImage('asset/image/me.jpg'),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                title: Text('Nama : Aziizah Intan Ramadhan N'),
              ),
            ),
            Card(
              child: ListTile(
                title: Text('NIM  : 123220201 '),
              ),
            ),
            Card(
              child: ListTile(
                title: Text('Kelas  : IF-C'),
              ),
            ),
            Card(
              child: ListTile(
                title: Text('Hobi : Membaca manhwa'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
