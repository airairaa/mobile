import 'package:flutter/material.dart';

class Layanglayang extends StatefulWidget {
  @override
  _LayanglayangState createState() => _LayanglayangState();
}

class _LayanglayangState extends State<Layanglayang> {
  final _alasController = TextEditingController();
  final _tinggiController = TextEditingController();
  final _sisi1Controller = TextEditingController();
  final _sisi2Controller = TextEditingController();

  double _luas = 0;
  double _keliling = 0;

  void _hitung() {
    if (_validateInput()) {
      double alas = double.parse(_alasController.text);
      double tinggi = double.parse(_tinggiController.text);
      double sisi1 = double.parse(_sisi1Controller.text);
      double sisi2 = double.parse(_sisi2Controller.text);

      setState(() {
        _luas = 0.5 * alas * tinggi;
        _keliling = 2 * (sisi1 + sisi2);
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Masukkan angka valid (maks 9 digit)')),
      );
    }
  }

  bool _validateInput() {
    // Cek apakah semua input adalah angka dan tidak lebih dari 9 digit
    return _isNumeric(_alasController.text) &&
        _isNumeric(_tinggiController.text) &&
        _isNumeric(_sisi1Controller.text) &&
        _isNumeric(_sisi2Controller.text) &&
        _alasController.text.length <= 9 &&
        _tinggiController.text.length <= 9 &&
        _sisi1Controller.text.length <= 9 &&
        _sisi2Controller.text.length <= 9;
  }

  bool _isNumeric(String str) {
    // Cek apakah string adalah angka
    return double.tryParse(str) != null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Layang-layang')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _alasController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Alas',
                errorText: _alasController.text.isEmpty
                    ? "Alas tidak boleh kosong!"
                    : null,
              ),
            ),
            TextField(
              controller: _tinggiController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Tinggi',
                errorText: _tinggiController.text.isEmpty
                    ? "Tinggi tidak boleh kosong!"
                    : null,
              ),
            ),
            TextField(
              controller: _sisi1Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Sisi 1',
                errorText: _sisi1Controller.text.isEmpty
                    ? "Sisi 1 tidak boleh kosong!"
                    : null,
              ),
            ),
            TextField(
              controller: _sisi2Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Sisi 2',
                errorText: _sisi2Controller.text.isEmpty
                    ? "Sisi 2 tidak boleh kosong!"
                    : null,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _hitung, child: Text('Hitung')),
            const SizedBox(height: 20),
            Text('Luas: $_luas'),
            Text('Keliling: $_keliling'),
          ],
        ),
      ),
    );
  }
}
