import 'package:flutter/material.dart';

class Tabung extends StatefulWidget {
  @override
  _TabungState createState() => _TabungState();
}

class _TabungState extends State<Tabung> {
  final _alasController = TextEditingController();
  final _tinggiController = TextEditingController();
  double _volume = 0;
  double _keliling = 0;

  void _hitung() {
    if (_validateInput()) {
      double alas = double.tryParse(_alasController.text) ?? 0;
      double tinggi = double.tryParse(_tinggiController.text) ?? 0;

      setState(() {
        _volume = 3.14 * alas * alas * tinggi; // Volume tabung
        _keliling = 2 * 3.14 * alas; // Keliling alas tabung
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Masukkan angka valid (maks 9 digit)')),
      );
    }
  }

  bool _validateInput() {
    return _isNumeric(_alasController.text) &&
        _isNumeric(_tinggiController.text) &&
        _alasController.text.isNotEmpty &&
        _tinggiController.text.isNotEmpty;
  }

  bool _isNumeric(String str) {
    return double.tryParse(str) != null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tabung')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _alasController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Jari-jari Alas'),
            ),
            TextField(
              controller: _tinggiController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Tinggi'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _hitung, child: Text('Hitung')),
            const SizedBox(height: 20),
            Text('Volume: $_volume'),
            Text('Keliling Alas: $_keliling'),
          ],
        ),
      ),
    );
  }
}
